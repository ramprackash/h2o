This resource has been created by Ixtendo for Ixtendo.com.



Terms of Use
------------

This is a free resource.

All the free resources provided by Ixtendo can be used in both personal and commercial projects.

You may freely use these resources, without restriction, in web templates, software programs and other materials intended for sale or distribution. No attribution or backlinks are strictly required, but we would appreciate it if you credited us for our work and spread the word.

You are not allowed to make the resources found on Ixtendo available for distribution elsewhere �as is� without prior consent. 

Ixtendo for Ixtendo.com
www.ixtendo.com




